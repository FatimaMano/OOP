﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kindom_s_Last_hope_GUI
{
    public enum GameGhostImage
    {
        BombImage,
        MainImage,
        TurtleImage,
    }
}
