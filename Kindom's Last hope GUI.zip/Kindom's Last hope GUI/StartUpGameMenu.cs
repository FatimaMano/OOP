﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kindom_s_Last_hope_GUI
{
    public partial class StartUpGameMenu : Form
    {
        public StartUpGameMenu()
        {
            InitializeComponent();
        }
    }
}
