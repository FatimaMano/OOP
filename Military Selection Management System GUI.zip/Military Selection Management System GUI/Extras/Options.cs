﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Selection_Management_System.Extras
{
     enum Options
    {
        SignIn,SignUp,
    }
}
