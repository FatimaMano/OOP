﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Military_Selection_Management_System.Extras
{
    class Time
    {
        public int hours;
        public int minutes;
        public Time(int hours, int minutes)
        {
            this.hours = hours;
            this.minutes = minutes;
        }
    }
}
