﻿namespace Military_Selection_Management_System_GUI.User
{
    partial class ApplicationReview
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            ApplicationReviewPanel = new Panel();
            ApplicationReviewTag = new Label();
            Nametag = new Label();
            IntermediateMarkstag = new Label();
            IDtag = new Label();
            MatricMarkstag = new Label();
            SelectionStatusTag = new Label();
            WeightTag = new Label();
            Heighttag = new Label();
            IntelligenceTestScoreTag = new Label();
            AcademicScoreTag = new Label();
            ResultPercentageTag = new Label();
            guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox7 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox8 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox9 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2TextBox10 = new Guna.UI2.WinForms.Guna2TextBox();
            ApplicationReviewPanel.SuspendLayout();
            SuspendLayout();
            // 
            // ApplicationReviewPanel
            // 
            ApplicationReviewPanel.BackColor = Color.FromArgb(24, 30, 54);
            ApplicationReviewPanel.Controls.Add(ApplicationReviewTag);
            ApplicationReviewPanel.Dock = DockStyle.Top;
            ApplicationReviewPanel.Location = new Point(0, 0);
            ApplicationReviewPanel.Margin = new Padding(3, 2, 3, 2);
            ApplicationReviewPanel.Name = "ApplicationReviewPanel";
            ApplicationReviewPanel.Size = new Size(1047, 92);
            ApplicationReviewPanel.TabIndex = 0;
            // 
            // ApplicationReviewTag
            // 
            ApplicationReviewTag.AutoSize = true;
            ApplicationReviewTag.Font = new Font("Broadway", 16F, FontStyle.Bold, GraphicsUnit.Point);
            ApplicationReviewTag.ForeColor = Color.White;
            ApplicationReviewTag.Location = new Point(339, 28);
            ApplicationReviewTag.Name = "ApplicationReviewTag";
            ApplicationReviewTag.Size = new Size(368, 36);
            ApplicationReviewTag.TabIndex = 0;
            ApplicationReviewTag.Text = "Application Review";
            // 
            // Nametag
            // 
            Nametag.AutoSize = true;
            Nametag.Location = new Point(39, 154);
            Nametag.Name = "Nametag";
            Nametag.Size = new Size(59, 25);
            Nametag.TabIndex = 1;
            Nametag.Text = "Name";
            // 
            // IntermediateMarkstag
            // 
            IntermediateMarkstag.AutoSize = true;
            IntermediateMarkstag.Location = new Point(476, 212);
            IntermediateMarkstag.Name = "IntermediateMarkstag";
            IntermediateMarkstag.Size = new Size(165, 25);
            IntermediateMarkstag.TabIndex = 2;
            IntermediateMarkstag.Text = "Intermediate Marks";
            // 
            // IDtag
            // 
            IDtag.AutoSize = true;
            IDtag.Location = new Point(490, 144);
            IDtag.Name = "IDtag";
            IDtag.Size = new Size(30, 25);
            IDtag.TabIndex = 3;
            IDtag.Text = "ID";
            // 
            // MatricMarkstag
            // 
            MatricMarkstag.AutoSize = true;
            MatricMarkstag.Location = new Point(26, 222);
            MatricMarkstag.Name = "MatricMarkstag";
            MatricMarkstag.Size = new Size(114, 25);
            MatricMarkstag.TabIndex = 4;
            MatricMarkstag.Text = "Matric Marks";
            // 
            // SelectionStatusTag
            // 
            SelectionStatusTag.AutoSize = true;
            SelectionStatusTag.Location = new Point(25, 453);
            SelectionStatusTag.Name = "SelectionStatusTag";
            SelectionStatusTag.Size = new Size(131, 25);
            SelectionStatusTag.TabIndex = 6;
            SelectionStatusTag.Text = "SelectionStatus";
            // 
            // WeightTag
            // 
            WeightTag.AutoSize = true;
            WeightTag.Location = new Point(490, 289);
            WeightTag.Name = "WeightTag";
            WeightTag.Size = new Size(68, 25);
            WeightTag.TabIndex = 7;
            WeightTag.Text = "Weight";
            // 
            // Heighttag
            // 
            Heighttag.AutoSize = true;
            Heighttag.Location = new Point(39, 299);
            Heighttag.Name = "Heighttag";
            Heighttag.Size = new Size(65, 25);
            Heighttag.TabIndex = 8;
            Heighttag.Text = "Height";
            // 
            // IntelligenceTestScoreTag
            // 
            IntelligenceTestScoreTag.AutoSize = true;
            IntelligenceTestScoreTag.Location = new Point(476, 381);
            IntelligenceTestScoreTag.Name = "IntelligenceTestScoreTag";
            IntelligenceTestScoreTag.Size = new Size(185, 25);
            IntelligenceTestScoreTag.TabIndex = 9;
            IntelligenceTestScoreTag.Text = "Intelligence Test Score";
            // 
            // AcademicScoreTag
            // 
            AcademicScoreTag.AutoSize = true;
            AcademicScoreTag.Location = new Point(26, 371);
            AcademicScoreTag.Name = "AcademicScoreTag";
            AcademicScoreTag.Size = new Size(173, 25);
            AcademicScoreTag.TabIndex = 10;
            AcademicScoreTag.Text = "Academic Test Score";
            // 
            // ResultPercentageTag
            // 
            ResultPercentageTag.AutoSize = true;
            ResultPercentageTag.Location = new Point(476, 453);
            ResultPercentageTag.Name = "ResultPercentageTag";
            ResultPercentageTag.Size = new Size(150, 25);
            ResultPercentageTag.TabIndex = 11;
            ResultPercentageTag.Text = "Result Percentage";
            // 
            // guna2TextBox2
            // 
            guna2TextBox2.CustomizableEdges = customizableEdges1;
            guna2TextBox2.DefaultText = "";
            guna2TextBox2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox2.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Location = new Point(205, 144);
            guna2TextBox2.Name = "guna2TextBox2";
            guna2TextBox2.PasswordChar = '\0';
            guna2TextBox2.PlaceholderText = "";
            guna2TextBox2.SelectedText = "";
            guna2TextBox2.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2TextBox2.Size = new Size(156, 35);
            guna2TextBox2.TabIndex = 13;
            // 
            // guna2TextBox7
            // 
            guna2TextBox7.CustomizableEdges = customizableEdges3;
            guna2TextBox7.DefaultText = "";
            guna2TextBox7.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox7.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox7.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox7.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox7.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox7.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox7.Location = new Point(696, 144);
            guna2TextBox7.Name = "guna2TextBox7";
            guna2TextBox7.PasswordChar = '\0';
            guna2TextBox7.PlaceholderText = "";
            guna2TextBox7.SelectedText = "";
            guna2TextBox7.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2TextBox7.Size = new Size(156, 35);
            guna2TextBox7.TabIndex = 19;
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.CustomizableEdges = customizableEdges5;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(696, 453);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderText = "";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2TextBox1.Size = new Size(156, 35);
            guna2TextBox1.TabIndex = 20;
            // 
            // guna2TextBox3
            // 
            guna2TextBox3.CustomizableEdges = customizableEdges7;
            guna2TextBox3.DefaultText = "";
            guna2TextBox3.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox3.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox3.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox3.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox3.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox3.Location = new Point(205, 453);
            guna2TextBox3.Name = "guna2TextBox3";
            guna2TextBox3.PasswordChar = '\0';
            guna2TextBox3.PlaceholderText = "";
            guna2TextBox3.SelectedText = "";
            guna2TextBox3.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2TextBox3.Size = new Size(156, 35);
            guna2TextBox3.TabIndex = 21;
            // 
            // guna2TextBox4
            // 
            guna2TextBox4.CustomizableEdges = customizableEdges9;
            guna2TextBox4.DefaultText = "";
            guna2TextBox4.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox4.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox4.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox4.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox4.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox4.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox4.Location = new Point(696, 289);
            guna2TextBox4.Name = "guna2TextBox4";
            guna2TextBox4.PasswordChar = '\0';
            guna2TextBox4.PlaceholderText = "";
            guna2TextBox4.SelectedText = "";
            guna2TextBox4.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2TextBox4.Size = new Size(156, 35);
            guna2TextBox4.TabIndex = 22;
            // 
            // guna2TextBox5
            // 
            guna2TextBox5.CustomizableEdges = customizableEdges11;
            guna2TextBox5.DefaultText = "";
            guna2TextBox5.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox5.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox5.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox5.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox5.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox5.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox5.Location = new Point(205, 371);
            guna2TextBox5.Name = "guna2TextBox5";
            guna2TextBox5.PasswordChar = '\0';
            guna2TextBox5.PlaceholderText = "";
            guna2TextBox5.SelectedText = "";
            guna2TextBox5.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2TextBox5.Size = new Size(156, 35);
            guna2TextBox5.TabIndex = 23;
            // 
            // guna2TextBox6
            // 
            guna2TextBox6.CustomizableEdges = customizableEdges13;
            guna2TextBox6.DefaultText = "";
            guna2TextBox6.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox6.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox6.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox6.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox6.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox6.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox6.Location = new Point(205, 289);
            guna2TextBox6.Name = "guna2TextBox6";
            guna2TextBox6.PasswordChar = '\0';
            guna2TextBox6.PlaceholderText = "";
            guna2TextBox6.SelectedText = "";
            guna2TextBox6.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2TextBox6.Size = new Size(156, 35);
            guna2TextBox6.TabIndex = 24;
            // 
            // guna2TextBox8
            // 
            guna2TextBox8.CustomizableEdges = customizableEdges15;
            guna2TextBox8.DefaultText = "";
            guna2TextBox8.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox8.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox8.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox8.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox8.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox8.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox8.Location = new Point(696, 212);
            guna2TextBox8.Name = "guna2TextBox8";
            guna2TextBox8.PasswordChar = '\0';
            guna2TextBox8.PlaceholderText = "";
            guna2TextBox8.SelectedText = "";
            guna2TextBox8.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2TextBox8.Size = new Size(156, 35);
            guna2TextBox8.TabIndex = 25;
            // 
            // guna2TextBox9
            // 
            guna2TextBox9.CustomizableEdges = customizableEdges17;
            guna2TextBox9.DefaultText = "";
            guna2TextBox9.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox9.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox9.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox9.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox9.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox9.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox9.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox9.Location = new Point(205, 212);
            guna2TextBox9.Name = "guna2TextBox9";
            guna2TextBox9.PasswordChar = '\0';
            guna2TextBox9.PlaceholderText = "";
            guna2TextBox9.SelectedText = "";
            guna2TextBox9.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2TextBox9.Size = new Size(156, 35);
            guna2TextBox9.TabIndex = 26;
            // 
            // guna2TextBox10
            // 
            guna2TextBox10.CustomizableEdges = customizableEdges19;
            guna2TextBox10.DefaultText = "";
            guna2TextBox10.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox10.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox10.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox10.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox10.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox10.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox10.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox10.Location = new Point(696, 371);
            guna2TextBox10.Name = "guna2TextBox10";
            guna2TextBox10.PasswordChar = '\0';
            guna2TextBox10.PlaceholderText = "";
            guna2TextBox10.SelectedText = "";
            guna2TextBox10.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2TextBox10.Size = new Size(156, 35);
            guna2TextBox10.TabIndex = 27;
            // 
            // ApplicationReview
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(guna2TextBox10);
            Controls.Add(guna2TextBox9);
            Controls.Add(guna2TextBox8);
            Controls.Add(guna2TextBox6);
            Controls.Add(guna2TextBox5);
            Controls.Add(guna2TextBox4);
            Controls.Add(guna2TextBox3);
            Controls.Add(guna2TextBox1);
            Controls.Add(guna2TextBox7);
            Controls.Add(guna2TextBox2);
            Controls.Add(ResultPercentageTag);
            Controls.Add(AcademicScoreTag);
            Controls.Add(IntelligenceTestScoreTag);
            Controls.Add(Heighttag);
            Controls.Add(WeightTag);
            Controls.Add(SelectionStatusTag);
            Controls.Add(MatricMarkstag);
            Controls.Add(IDtag);
            Controls.Add(IntermediateMarkstag);
            Controls.Add(Nametag);
            Controls.Add(ApplicationReviewPanel);
            Margin = new Padding(3, 2, 3, 2);
            Name = "ApplicationReview";
            Size = new Size(1047, 570);
            ApplicationReviewPanel.ResumeLayout(false);
            ApplicationReviewPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel ApplicationReviewPanel;
        private Label ApplicationReviewTag;
        private Label Nametag;
        private Label IntermediateMarkstag;
        private Label IDtag;
        private Label MatricMarkstag;
        private Label SelectionStatusTag;
        private Label WeightTag;
        private Label Heighttag;
        private Label IntelligenceTestScoreTag;
        private Label AcademicScoreTag;
        private Label ResultPercentageTag;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox8;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox9;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox10;
    }
}
