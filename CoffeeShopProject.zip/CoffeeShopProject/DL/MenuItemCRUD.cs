﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MenuItemProject.BL;

namespace MenuItemCRUD
 class MenuItemDL
{
	public MenuItemDL()
	{
	}

    public void addMenuItem(MenuItem)
    {

    }
}
