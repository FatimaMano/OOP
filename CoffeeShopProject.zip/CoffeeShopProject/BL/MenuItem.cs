﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoffeeShopProject.BL;

namespace MenuItemProject.BL
{
    class MenuItem
    {
        public string Name;
        public string type;
        public float price;
    } 
    public static void addMenuItem(MenuItem item)
    {
        menu.Add(item)
    }
}
